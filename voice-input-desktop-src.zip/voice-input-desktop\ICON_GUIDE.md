# 桌面端编译说明

## 当前状态

桌面端代码已完成，但编译需要图标文件。

## 解决方案

### 方案 1: 使用开发模式（推荐）✅

开发模式不需要图标文件，可以立即运行：

```bash
cd E:\Work\Code\voiceinput\voice-input-desktop
npm run dev
```

这会启动应用，功能完全可用，只是没有打包成安装程序。

### 方案 2: 下载图标文件

从以下网站下载图标：

1. **Flaticon** (https://www.flaticon.com/)
   - 搜索 "microphone" 或 "voice"
   - 下载 512x512 PNG 格式

2. **Icons8** (https://icons8.com/)
   - 搜索 "microphone"
   - 下载多种尺寸

3. **使用在线工具生成**
   - https://icon.kitchen/
   - 上传一张图片，自动生成所有尺寸

### 方案 3: 使用 Tauri CLI 生成图标

如果你有一张 PNG 图片：

```bash
# 安装 Tauri CLI
npm install -g @tauri-apps/cli

# 生成图标（需要一张 1024x1024 的 PNG）
tauri icon path/to/your-icon.png
```

### 方案 4: 从 Tauri 示例复制

```bash
# 克隆 Tauri 示例
git clone --depth 1 https://github.com/tauri-apps/tauri.git temp-tauri

# 复制图标
cp -r temp-tauri/examples/api/src-tauri/icons/* voice-input-desktop/src-tauri/icons/

# 删除临时文件
rm -rf temp-tauri
```

## 需要的图标文件

放到 `src-tauri/icons/` 目录：

- `32x32.png` - 32x32 像素
- `128x128.png` - 128x128 像素
- `128x128@2x.png` - 256x256 像素
- `icon.icns` - macOS 图标
- `icon.ico` - Windows 图标
- `icon.png` - 通用图标（512x512 或更大）

## 临时解决方案

如果只是想测试功能，使用开发模式即可：

```bash
npm run dev
```

开发模式提供完整功能，只是没有打包成安装程序。

## 完整编译

准备好图标文件后：

```bash
npm run build
```

输出位置：
- Windows: `src-tauri\target\release\bundle\msi\`
- 可执行文件: `src-tauri\target\release\voice-input-desktop.exe`
