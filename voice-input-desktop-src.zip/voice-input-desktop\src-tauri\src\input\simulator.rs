use enigo::{Enigo, Settings, Keyboard};

pub fn simulate_text_input(text: &str) {
    let settings = Settings::default();
    let mut enigo = Enigo::new(&settings).unwrap();
    enigo.text(text).ok();
}
