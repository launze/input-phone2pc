mod network;
mod input;
mod pairing;
mod storage;
mod crypto;

use storage::config::AppConfig;
use std::sync::Arc;
use tokio::sync::Mutex;

// 全局服务器连接状态
struct ServerState {
    connected: bool,
    error: Option<String>,
}

lazy_static::lazy_static! {
    static ref SERVER_STATE: Arc<Mutex<ServerState>> = Arc::new(Mutex::new(ServerState {
        connected: false,
        error: None,
    }));
}

#[tauri::command]
fn get_config() -> AppConfig {
    AppConfig::load()
}

#[tauri::command]
fn set_server_url(url: String) -> Result<(), String> {
    let mut config = AppConfig::load();
    config.set_server_url(url);
    config.save().map_err(|e| e.to_string())
}

#[tauri::command]
fn set_server_mode(enabled: bool) -> Result<(), String> {
    let mut config = AppConfig::load();
    config.set_server_mode(enabled);
    config.save().map_err(|e| e.to_string())
}

#[tauri::command]
async fn connect_server(url: String) -> Result<(), String> {
    println!("🔌 正在连接服务器: {}", url);

    // 断开之前的连接
    {
        let ws_client = network::websocket::get_ws_client();
        let mut client = ws_client.lock().await;
        client.disconnect().await;
    }

    // 加载设备配置
    let config = storage::config::AppConfig::load();

    // 连接并注册
    network::connect_and_register(&url, &config.device_id, &config.device_name).await;

    // 检查连接状态
    let ws_client = network::websocket::get_ws_client();
    let client = ws_client.lock().await;
    if client.is_connected().await {
        let mut state = SERVER_STATE.lock().await;
        state.connected = true;
        state.error = None;
        Ok(())
    } else {
        let mut state = SERVER_STATE.lock().await;
        state.connected = false;
        state.error = Some("连接失败".to_string());
        Err("连接失败".to_string())
    }
}

#[tauri::command]
async fn disconnect_server() -> Result<(), String> {
    println!("🔌 断开服务器连接");
    
    // 断开 WebSocket 连接
    let ws_client = network::websocket::get_ws_client();
    let mut client = ws_client.lock().await;
    client.disconnect().await;
    
    let mut state = SERVER_STATE.lock().await;
    state.connected = false;
    state.error = None;
    
    Ok(())
}

#[derive(serde::Serialize)]
struct ServerStatus {
    connected: bool,
    error: Option<String>,
}

#[tauri::command]
async fn get_server_status() -> ServerStatus {
    // 检查 WebSocket 实际连接状态
    let ws_client = network::websocket::get_ws_client();
    let client = ws_client.lock().await;
    let ws_connected = client.is_connected().await;
    
    let mut state = SERVER_STATE.lock().await;
    
    // 同步状态
    if state.connected != ws_connected {
        state.connected = ws_connected;
        if !ws_connected {
            state.error = Some("连接已断开".to_string());
        }
    }
    
    ServerStatus {
        connected: state.connected,
        error: state.error.clone(),
    }
}

#[tauri::command]
async fn generate_encryption_key() -> Result<String, String> {
    let key = crate::crypto::EncryptionKey::generate();
    Ok(key.to_hex())
}

#[tauri::command]
async fn set_encryption_key(key: String) -> Result<(), String> {
    use crate::crypto::EncryptionKey;
    let encryption_key = EncryptionKey::from_hex(&key)
        .map_err(|e| e.to_string())?;
    
    // 设置到网络模块
    use crate::network::connection;
    connection::set_encryption_key(Some(encryption_key)).await;
    
    println!("设置加密密钥成功");
    Ok(())
}

#[tauri::command]
async fn send_encrypted_message(_message: String, to_device_id: String) -> Result<(), String> {
    // 这里需要获取加密密钥并发送加密消息
    // 实际实现需要根据网络连接状态来发送
    println!("发送加密消息到设备: {}", to_device_id);
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            get_config,
            set_server_url,
            set_server_mode,
            connect_server,
            disconnect_server,
            get_server_status,
            generate_encryption_key,
            set_encryption_key,
            send_encrypted_message
        ])
        .setup(|app| {
            let app_handle = app.handle().clone();
            
            // 启动网络服务
            tauri::async_runtime::spawn(async move {
                if let Err(e) = network::start_services(app_handle).await {
                    eprintln!("网络服务启动失败: {}", e);
                }
            });
            
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

fn main() {
    // 初始化 Rustls 加密提供者
    use rustls::crypto::ring::default_provider;
    let _ = default_provider().install_default();
    
    run();
}
