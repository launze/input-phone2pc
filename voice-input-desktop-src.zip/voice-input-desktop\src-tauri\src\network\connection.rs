use tokio::net::{TcpListener, TcpStream};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tauri::{AppHandle, Emitter};
use std::error::Error;
use crate::input;
use crate::crypto::{EncryptionKey, encrypt_string, decrypt_string};
use std::sync::Arc;
use tokio::sync::Mutex;

lazy_static::lazy_static! {
    static ref ENCRYPTION_KEY: Arc<Mutex<Option<EncryptionKey>>> = Arc::new(Mutex::new(None));
}

pub async fn get_encryption_key() -> Option<EncryptionKey> {
    ENCRYPTION_KEY.lock().await.clone()
}

pub async fn set_encryption_key(key: Option<EncryptionKey>) {
    *ENCRYPTION_KEY.lock().await = key;
}

pub async fn start_tcp_server(app_handle: AppHandle) -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:58889").await?;
    println!("TCP 服务器启动: 0.0.0.0:58889");

    loop {
        let (socket, addr) = listener.accept().await?;
        println!("新连接: {}", addr);
        
        let app = app_handle.clone();
        tokio::spawn(async move {
            if let Err(e) = handle_client(socket, app).await {
                eprintln!("处理客户端错误: {}", e);
            }
        });
    }
}

async fn handle_client(socket: TcpStream, app_handle: AppHandle) -> Result<(), Box<dyn Error>> {
    // 通知前端设备已连接
    app_handle.emit("device_connected", Some(serde_json::json!({
        "device_name": "Android设备",
        "connected_at": chrono::Utc::now().to_rfc3339()
    }))).unwrap_or(());
    println!("📱 通知前端：设备已连接");
    let (reader, mut writer) = socket.into_split();
    let mut reader = BufReader::new(reader);
    let mut line = String::new();

    loop {
        line.clear();
        let n = reader.read_line(&mut line).await?;
        
        if n == 0 {
            // 通知前端设备已断开
            app_handle.emit("device_disconnected", Some(serde_json::json!({
                "disconnected_at": chrono::Utc::now().to_rfc3339()
            }))).unwrap_or(());
            println!("📱 通知前端：设备已断开");
            break;
        }

        let message: serde_json::Value = serde_json::from_str(&line)?;
        
        if let Some(msg_type) = message.get("type").and_then(|v| v.as_str()) {
            match msg_type {
                "ENCRYPTION_KEY_EXCHANGE" => {
                    // 处理密钥交换
                    if let Some(public_key) = message.get("public_key").and_then(|v| v.as_str()) {
                        if let Ok(key) = EncryptionKey::from_hex(public_key) {
                            set_encryption_key(Some(key)).await;
                            println!("设置加密密钥成功");
                        }
                    }
                }
                "ENCRYPTED_MESSAGE" => {
                    // 处理加密消息
                    if let Some(ciphertext) = message.get("ciphertext").and_then(|v| v.as_str()) {
                        if let Some(nonce) = message.get("nonce").and_then(|v| v.as_str()) {
                            if let Some(key) = get_encryption_key().await {
                                if let Ok(decrypted_json) = decrypt_string(ciphertext, nonce, &key) {
                                    if let Ok(decrypted_message) = serde_json::from_str::<serde_json::Value>(&decrypted_json) {
                                        if let Some(decrypted_type) = decrypted_message.get("type").and_then(|v| v.as_str()) {
                                            match decrypted_type {
                                                "TEXT_INPUT" => {
                                                    if let Some(text) = decrypted_message.get("text").and_then(|v| v.as_str()) {
                                                        input::simulate_text_input(text);
                                                        
                                                        let response = serde_json::json!({
                                                            "type": "INPUT_ACK",
                                                            "success": true
                                                        });
                                                        writer.write_all(response.to_string().as_bytes()).await?;
                                                        writer.write_all(b"\n").await?;
                                                    }
                                                }
                                                _ => {}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                "TEXT_INPUT" => {
                    if let Some(text) = message.get("text").and_then(|v| v.as_str()) {
                        input::simulate_text_input(text);
                        
                        let response = serde_json::json!({
                            "type": "INPUT_ACK",
                            "success": true
                        });
                        writer.write_all(response.to_string().as_bytes()).await?;
                        writer.write_all(b"\n").await?;
                    }
                }
                "HEARTBEAT" => {
                    let response = serde_json::json!({
                        "type": "HEARTBEAT",
                        "timestamp": chrono::Utc::now().timestamp_millis()
                    });
                    writer.write_all(response.to_string().as_bytes()).await?;
                    writer.write_all(b"\n").await?;
                }
                _ => {}
            }
        }
    }

    Ok(())
}
