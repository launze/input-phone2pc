pub mod discovery;
pub mod connection;
pub mod protocol;
pub mod websocket;

use tauri::AppHandle;
use std::error::Error;

pub async fn start_services(app_handle: AppHandle) -> Result<(), Box<dyn Error>> {
    // 启动 UDP 发现服务
    let discovery_handle = app_handle.clone();
    tokio::spawn(async move {
        if let Err(e) = discovery::start_discovery_service(discovery_handle).await {
            eprintln!("UDP 发现服务错误: {}", e);
        }
    });

    // 启动 TCP 服务器
    let tcp_handle = app_handle.clone();
    tokio::spawn(async move {
        if let Err(e) = connection::start_tcp_server(tcp_handle).await {
            eprintln!("TCP 服务器错误: {}", e);
        }
    });

    // 检查是否启用了服务端模式，如果是则自动连接 WSS 服务器
    let config = crate::storage::config::AppConfig::load();
    if config.server_mode_enabled && !config.server_url.is_empty() {
        println!("服务端模式已启用，自动连接到: {}", config.server_url);
        connect_and_register(&config.server_url, &config.device_id, &config.device_name).await;
    }

    Ok(())
}

/// Connect to WSS server, register device, and start handling messages
pub async fn connect_and_register(url: &str, device_id: &str, device_name: &str) {
    let ws_client = websocket::get_ws_client();
    let mut client = ws_client.lock().await;

    match client.connect(url).await {
        Ok(mut rx) => {
            println!("✅ WSS 服务器连接成功: {}", url);

            // Send SERVER_REGISTER
            let register_msg = serde_json::json!({
                "type": "SERVER_REGISTER",
                "device_id": device_id,
                "device_name": device_name,
                "device_type": "desktop",
                "version": "1.2.0"
            });
            if let Err(e) = client.send(&register_msg.to_string()).await {
                eprintln!("❌ 发送注册消息失败: {}", e);
                return;
            }
            println!("📤 已发送 SERVER_REGISTER: device_id={}, name={}", device_id, device_name);

            // Release the lock before spawning the message handler
            drop(client);

            let dev_id = device_id.to_string();
            // Start message handler
            tokio::spawn(async move {
                handle_server_messages(rx, dev_id).await;
            });

            // Start heartbeat
            tokio::spawn(async move {
                server_heartbeat().await;
            });
        }
        Err(e) => {
            eprintln!("❌ WSS 服务器连接失败: {}", e);
        }
    }
}

async fn handle_server_messages(mut rx: tokio::sync::mpsc::UnboundedReceiver<String>, my_device_id: String) {
    while let Some(text) = rx.recv().await {
        println!("📨 服务器消息: {}", &text[..text.len().min(200)]);

        let msg: serde_json::Value = match serde_json::from_str(&text) {
            Ok(v) => v,
            Err(e) => {
                eprintln!("❌ 解析消息失败: {}", e);
                continue;
            }
        };

        let msg_type = msg.get("type").and_then(|v| v.as_str()).unwrap_or("");
        match msg_type {
            "SERVER_REGISTER_RESPONSE" => {
                let success = msg.get("success").and_then(|v| v.as_bool()).unwrap_or(false);
                let session_id = msg.get("session_id").and_then(|v| v.as_str()).unwrap_or("");
                if success {
                    println!("✅ 服务器注册成功, session_id={}", session_id);
                } else {
                    let message = msg.get("message").and_then(|v| v.as_str()).unwrap_or("unknown");
                    eprintln!("❌ 服务器注册失败: {}", message);
                }
            }
            "RELAY_MESSAGE" => {
                let from_id = msg.get("from_device_id").and_then(|v| v.as_str()).unwrap_or("unknown");
                if let Some(payload) = msg.get("payload") {
                    let payload_type = payload.get("type").and_then(|v| v.as_str()).unwrap_or("");
                    println!("📨 中转消息 from {}: type={}", from_id, payload_type);

                    match payload_type {
                        "TEXT_INPUT" => {
                            if let Some(text) = payload.get("text").and_then(|v| v.as_str()) {
                                println!("⌨️ 模拟输入: {}", text);
                                crate::input::simulate_text_input(text);

                                // Send INPUT_ACK back via relay
                                let ack_payload = serde_json::json!({
                                    "type": "INPUT_ACK",
                                    "success": true,
                                    "timestamp": chrono::Utc::now().timestamp_millis()
                                });
                                let relay_ack = serde_json::json!({
                                    "type": "RELAY_MESSAGE",
                                    "from_device_id": my_device_id,
                                    "to_device_id": from_id,
                                    "payload": ack_payload
                                });
                                let ws_client = websocket::get_ws_client();
                                let client = ws_client.lock().await;
                                if let Err(e) = client.send(&relay_ack.to_string()).await {
                                    eprintln!("❌ 发送 INPUT_ACK 失败: {}", e);
                                }
                            }
                        }
                        _ => {
                            println!("⚠️ 未处理的中转消息类型: {}", payload_type);
                        }
                    }
                }
            }
            "HEARTBEAT" => {
                // Server heartbeat response, ignore
            }
            "DEVICE_LIST_RESPONSE" => {
                if let Some(devices) = msg.get("devices").and_then(|v| v.as_array()) {
                    println!("📋 在线设备列表: {} 个设备", devices.len());
                    for d in devices {
                        let name = d.get("device_name").and_then(|v| v.as_str()).unwrap_or("?");
                        let dtype = d.get("device_type").and_then(|v| v.as_str()).unwrap_or("?");
                        println!("  - {} ({})", name, dtype);
                    }
                }
            }
            "ERROR" => {
                let code = msg.get("code").and_then(|v| v.as_str()).unwrap_or("?");
                let message = msg.get("message").and_then(|v| v.as_str()).unwrap_or("?");
                eprintln!("❌ 服务器错误: [{}] {}", code, message);
            }
            _ => {
                println!("⚠️ 未知消息类型: {}", msg_type);
            }
        }
    }
    println!("🔌 服务器消息接收结束");
}

async fn server_heartbeat() {
    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(30));
    loop {
        interval.tick().await;
        let ws_client = websocket::get_ws_client();
        let client = ws_client.lock().await;
        if client.is_connected().await {
            let heartbeat = serde_json::json!({
                "type": "HEARTBEAT",
                "timestamp": chrono::Utc::now().timestamp_millis()
            });
            if let Err(e) = client.send(&heartbeat.to_string()).await {
                eprintln!("❌ 发送心跳失败: {}", e);
                break;
            }
        } else {
            break;
        }
    }
}
