// 引入 Tauri API
const invoke = window.__TAURI_INTERNALS__.invoke;

document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 应用已加载');
    
    const statusIndicator = document.getElementById('status-indicator');
    const statusText = document.getElementById('status-text');
    const connectionInfo = document.getElementById('connection-info');
    const deviceInfo = document.getElementById('device-info');
    const deviceName = document.getElementById('device-name');
    const connectTime = document.getElementById('connect-time');
    
    // 服务器设置
    const serverModeToggle = document.getElementById('server-mode-toggle');
    const serverUrlInput = document.getElementById('server-url');
    
    // 服务器连接状态元素
    const serverConnectionStatus = document.getElementById('server-connection-status');
    const serverStatusCard = document.getElementById('server-status-card');
    const serverStatusIcon = document.getElementById('server-status-icon');
    const serverStatusText = document.getElementById('server-status-text');
    const serverConnectTime = document.getElementById('server-connect-time');
    const connectServerBtn = document.getElementById('connect-server-btn');
    const disconnectServerBtn = document.getElementById('disconnect-server-btn');

    console.log('✅ 所有元素已获取');
    console.log('serverConnectionStatus:', serverConnectionStatus);
    console.log('connectServerBtn:', connectServerBtn);

    // 加载配置
    try {
        const config = await invoke('get_config');
        console.log('📋 配置已加载:', config);
        
        serverModeToggle.checked = config.server_mode_enabled;
        serverUrlInput.value = config.server_url;
        serverUrlInput.disabled = !config.server_mode_enabled;
        
        if (config.server_mode_enabled) {
            serverConnectionStatus.style.display = 'block';
            console.log('✅ 服务器模式已启用，显示连接状态');
        } else {
            serverConnectionStatus.style.display = 'none';
            console.log('❌ 服务器模式未启用，隐藏连接状态');
        }
    } catch (error) {
        console.error('❌ 加载配置失败:', error);
    }

    // 服务器模式切换
    serverModeToggle.addEventListener('change', async (e) => {
        const enabled = e.target.checked;
        console.log('🔄 服务器模式切换:', enabled);
        
        serverUrlInput.disabled = !enabled;
        
        if (enabled) {
            serverConnectionStatus.style.display = 'block';
            console.log('✅ 显示连接状态区域');
        } else {
            serverConnectionStatus.style.display = 'none';
            console.log('❌ 隐藏连接状态区域');
        }
        
        try {
            await invoke('set_server_mode', { enabled });
            console.log('💾 服务器模式已保存');
            
            if (!enabled) {
                await invoke('disconnect_server');
                updateServerStatus('disconnected');
            }
        } catch (error) {
            console.error('❌ 设置服务器模式失败:', error);
            e.target.checked = !enabled;
        }
    });

    // 服务器地址输入时自动保存
    serverUrlInput.addEventListener('input', async (e) => {
        const url = e.target.value.trim();
        if (url) {
            try {
                await invoke('set_server_url', { url });
                console.log('💾 服务器地址已保存:', url);
            } catch (error) {
                console.error('❌ 保存服务器地址失败:', error);
            }
        }
    });

    // 连接服务器
    connectServerBtn.addEventListener('click', async () => {
        console.log('🔌 点击连接按钮');
        const url = serverUrlInput.value.trim();
        if (!url) {
            alert('请先输入服务器地址');
            return;
        }

        try {
            updateServerStatus('connecting');
            await invoke('connect_server', { url });
            console.log('✅ 连接请求已发送');
            // 模拟连接成功（因为当前是模拟实现）
            setTimeout(() => {
                updateServerStatus('connected');
            }, 1000);
        } catch (error) {
            console.error('❌ 连接服务器失败:', error);
            alert('连接失败: ' + error);
            updateServerStatus('error', error.toString());
        }
    });

    // 断开服务器
    disconnectServerBtn.addEventListener('click', async () => {
        console.log('🔌 点击断开按钮');
        try {
            await invoke('disconnect_server');
            updateServerStatus('disconnected');
            console.log('✅ 已断开服务器连接');
        } catch (error) {
            console.error('❌ 断开连接失败:', error);
        }
    });

    // 更新服务器连接状态
    function updateServerStatus(status, message = '') {
        console.log('📊 更新状态:', status, message);
        switch (status) {
            case 'disconnected':
                serverStatusIcon.textContent = '🔴';
                serverStatusText.textContent = '未连接';
                serverStatusCard.style.backgroundColor = '#fee';
                serverConnectTime.style.display = 'none';
                connectServerBtn.style.display = 'inline-block';
                disconnectServerBtn.style.display = 'none';
                break;
            case 'connecting':
                serverStatusIcon.textContent = '🟡';
                serverStatusText.textContent = '连接中...';
                serverStatusCard.style.backgroundColor = '#ffc';
                serverConnectTime.style.display = 'none';
                connectServerBtn.style.display = 'none';
                disconnectServerBtn.style.display = 'none';
                break;
            case 'connected':
                serverStatusIcon.textContent = '🟢';
                serverStatusText.textContent = '已连接到 ' + serverUrlInput.value;
                serverStatusCard.style.backgroundColor = '#efe';
                serverConnectTime.textContent = '连接时间: ' + new Date().toLocaleString('zh-CN');
                serverConnectTime.style.display = 'block';
                connectServerBtn.style.display = 'none';
                disconnectServerBtn.style.display = 'inline-block';
                break;
            case 'error':
                serverStatusIcon.textContent = '❌';
                serverStatusText.textContent = '错误: ' + message;
                serverStatusCard.style.backgroundColor = '#fee';
                serverConnectTime.style.display = 'none';
                connectServerBtn.style.display = 'inline-block';
                disconnectServerBtn.style.display = 'none';
                break;
        }
    }

    // 定期检查服务器连接状态
    setInterval(async () => {
        if (serverModeToggle.checked) {
            try {
                const status = await invoke('get_server_status');
                if (status.connected) {
                    updateServerStatus('connected');
                } else if (status.error) {
                    updateServerStatus('error', status.error);
                }
            } catch (error) {
                // 忽略错误
            }
        }
    }, 5000);

    // 更新设备连接状态
    function updateConnectionStatus(connected, name = null) {
        if (connected) {
            statusIndicator.classList.add('connected');
            statusText.textContent = '已连接';
            connectionInfo.style.display = 'none';
            deviceInfo.style.display = 'flex';
            deviceName.textContent = name || '未知设备';
            connectTime.textContent = new Date().toLocaleTimeString('zh-CN');
        } else {
            statusIndicator.classList.remove('connected');
            statusText.textContent = '等待连接';
            connectionInfo.style.display = 'block';
            deviceInfo.style.display = 'none';
        }
    }

    console.log('✅ 语音输入助手前端已加载完成');

    // 监听设备连接事件
    window.__TAURI_INTERNALS__.listen('device_connected', (event) => {
        console.log('📱 收到设备连接事件:', event);
        const deviceName = event.payload?.device_name || 'Android设备';
        updateConnectionStatus(true, deviceName);
    });

    // 监听设备断开事件
    window.__TAURI_INTERNALS__.listen('device_disconnected', (event) => {
        console.log('📱 收到设备断开事件:', event);
        updateConnectionStatus(false);
    });
});
